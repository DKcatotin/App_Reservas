import '../../../../../core/storage/token_storage.dart';
import '../../models/auth_response.dart';
import '../../sources/auth/auth_api.dart';

class AuthRepository {
  final AuthApi api;
  final TokenStorage tokenStorage;

  AuthRepository({required this.api, required this.tokenStorage});
Future<void> signIn(String username, String password) async {
  final auth = await api.signIn(
    username: username,
    password: password,
  );

  await tokenStorage.saveAccessToken(auth.accessToken);
}

  Future<void> signOut() async {
    await tokenStorage.clear();
  }
   Future<AuthResponse> greetPrivate() async {
    return await api.greetPrivate();

  }
}
