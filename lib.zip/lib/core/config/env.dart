class Env {
  // Android emulator:
  static const String baseUrl = 'http://10.0.2.2:3000/api/v1';
}
